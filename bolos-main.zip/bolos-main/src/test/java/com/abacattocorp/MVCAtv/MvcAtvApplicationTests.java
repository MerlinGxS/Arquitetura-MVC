package com.abacattocorp.MVCAtv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvcAtvApplicationTests {

	@Test
	void contextLoads() {
	}

}
